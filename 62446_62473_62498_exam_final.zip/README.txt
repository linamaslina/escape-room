Съдържание на архива:
index.php 
В папка css
game.css
style.css
В папка js
game.js
script.js
service-worker.js
В папка graphics имаме
папка media
1.png
папка rooms
с папка bedroom
bed-teddy-zoom.png
bed-teddy.png
bed.png
bedroom_window.png
cabinet-open.png
cabinet.svg
candle.svg
candle2.png
candle2.svg
chair.png
fire-extinguisher.svg
key.svg
lamp.png
tshirt.png
wateringcan.png
с папка exit
door-lock.png
door.jpg
hanger.png
shoe1.svg
shoe2.svg
с папка kitchen
calendar-correct.png
calendar.png
calendar2.png
chair.png
fire.svg
fruitbowl.png
fruitbowl1.png
fruitbowl2.png
fruitbowl3.png
fruitbowl4.png
kitchen_window.png
oven.png
pan.png
table.png
teddy.png
teddy2.png
с папка office
apple.png
code.png
desk.png
europe-map.png
flower.png
flower2.png
letter.png
lightbulb.png
london_picture.png
map.svg
office_chair.png
office_chair2.png
pocketlighter.png
Други в папка graphics
exit.svg
room_template.svg
room_template_mirrored.svg
В папка includes
dbh.inc.php
submit.inc.php
Други файлове
database.sql
ranking.php
saveRanking.php
62446_62473_62498_Documentation.docx
62446_62473_62498_README.txt
readme.txt
Имена: Веселина Послийска, Виктория Месова, Ирина Христова
Забележки към подкарването - За добавянето на базата данни е необходимо да се импортира SQL скрипта “escape-room/database.sql”. 
След това се пуска XAMPP и в браузъра се пише localhost/escape-room/main.php за стартиране на играта.
