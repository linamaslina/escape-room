<?php

$dbServername = "localhost";
$dbUsername = "root";
$dbTime = "";
$dbName = "scoreboard";

$conn = mysqli_connect($dbServername, $dbUsername, $dbTime, $dbName);

?>